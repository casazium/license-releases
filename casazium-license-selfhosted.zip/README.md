# Casazium License Server — Self-Hosted Quickstart

Everything in this folder is all you need to run your own copy of the
Casazium License Server. No source code access required — this pulls
the published, public Docker image.

## 1. Prerequisites

- [Docker](https://docs.docker.com/get-docker/) and Docker Compose (bundled with Docker Desktop)
- Your activation license file, if you've already purchased one (see step 4)

## 2. Configure

```bash
cp .env.example .env
```

The four required secrets (`ADMIN_API_KEY`, `ENCRYPTION_KEY`,
`LICENSE_SIGNING_SECRET`, `LICENSE_RSA_PRIVATE_KEY`) are generated for
you automatically on first boot — you can leave `.env` as-is. Generated
values are saved to `./data/.secrets.json` (next to your database), so
restarting reuses the same ones instead of minting new secrets each
time. Back that file up along with the rest of `./data`: losing it
invalidates every license file you've exported and your admin API key.

Want to set your own values instead (e.g. restoring a previous
deployment)? Fill them in yourself in `.env` — each has a ready-to-run
generator command in `.env.example`'s own comments. Anything you set
explicitly always takes precedence and is never overwritten.

## 3. Start it

```bash
mkdir -p data
docker compose up -d
```

The server will be available at `http://localhost:3001`.

## 4. Activate your license

Without a license configured, the server refuses to start — this is
expected, not a bug. You have two options:

**A. Evaluate first, no license yet.** Set `CASAZIUM_UNLICENSED_EVAL=1`
in `.env` and restart (`docker compose up -d`). This unlocks a
30-day evaluation window, logged loudly on every boot. Not for
production use. The window is measured from when the image itself was
built, not from when you first ran it — a fresh `docker pull` of
`latest` (even for an unrelated fix) gets a new build time, so
pulling and restarting resets your 30 days regardless of how long
you'd already been running the previous image. Don't rely on this to
extend an evaluation on purpose; a real license removes the question
entirely.

**B. You already have a license.** You'll have received a `license.json`
file after purchase. Place it in this same folder, then:

1. In `docker-compose.yml`, uncomment the `./license.json:/app/license.json:ro`
   line under `volumes:`.
2. In `.env`, set `TIER_A_LICENSE_FILE=/app/license.json`.
3. Restart: `docker compose up -d`.

## 5. Verify it's running

```bash
curl http://localhost:3001/
```

You should see a JSON response with `"message": "License API is running"`.

To check specifically that your license was accepted, look at the
container logs:

```bash
docker compose logs license | grep tier-a-license
```

A successful activation logs `tier-a-license: valid activation license
found` along with the name it was issued to and its expiry date.
Evaluation mode logs `tier-a-license: no valid activation license -
proceeding under a time-limited evaluation allowance, not for
production use (expires <timestamp>)` — that's when this image's own
evaluation window runs out, per step 4 above. A refused boot logs
`tier-a-license: refusing to start (<reason>)` and the container
exits — check the reason against step 4 above.

## Next steps

- [Full documentation](https://docs.casazium.com/docs/license-server/getting-started/installation) —
  environment variables, Kubernetes deployment, issuing licenses to
  your own customers, and more.
- Questions? Email [hello@casazium.com](mailto:hello@casazium.com).
